

//////////////////////////////////////////////////////////////
    // *******************************
    // Definición de productos
    // *******************************
    const productos = [
      { id: 0001, nombre: "Remera", precio: 5000 },
      { id: 0002, nombre: "Pantalón", precio: 12000 },
      { id: 0003, nombre: "Zapatillas", precio: 25000 },
      { id: 0004, nombre: "Campera", precio: 20000 },
      { id: 0005, nombre: "Medias Blacas" , precio: 500 },
      { id: 0006, nombre: " Medias Negras" , precio: 550 },
      { id: 0007, nombre: "Medias Rojas" , precio: 600 },
      { id: 0008, nombre: "Gorro Adidas" , precio: 6500 },
      { id: 0009, nombre: "Gorro Nike" , precio: 6500 }
    ];

    let carrito = [];
    let reservas = [];

    // *******************************
    // Funciones
    // *******************************
    function mostrarProductos() {
      console.log("Productos disponibles:");
     productos.forEach(p => {
       console.log(`${p.id}: ${p.nombre} - $${p.precio}`);
      });
 //      for (let i = 0 ; i < productos.length ; i++){
 //       console.log(productos[i]);
    } 

    function agregarAlCarrito(idProducto) {
      const producto = productos.find(p => p.id === idProducto);
      if (producto) {
        carrito.push(producto);
        console.log(`${producto.nombre} agregado al carrito.`);
      } else {
        console.log("Producto no encontrado.");
      }
    }

    function mostrarCarrito() {
      console.log("Carrito actual:");
      carrito.forEach((p, i) => {
        console.log(`${i + 1}: ${p.nombre} - $${p.precio}`);
      });
      const total = carrito.reduce((sum, p) => sum + p.precio, 0);
      console.log(`Total: $${total}`);
    }

    function hacerReserva(idProducto, nombreCliente, fecha) {
      const producto = productos.find(p => p.id === idProducto);
      if (producto) {
        const reserva = {
          idReserva: reservas.length + 1,
          producto: producto,
          cliente: nombreCliente,
          fecha: fecha
        };
        reservas.push(reserva);
        console.log(`Reserva creada: ${reserva.cliente} reservó ${producto.nombre} para el ${reserva.fecha}`);
      } else {
        console.log("Producto no encontrado para reservar.");
      }
    
    }

    function mostrarReservas() {
      console.log("Reservas realizadas:");
      reservas.forEach(r => {
        console.log(`ID Reserva: ${r.idReserva} | Cliente: ${r.cliente} | Producto: ${r.producto.nombre} | Fecha: ${r.fecha}`);
      });
    }

    // *******************************
    // Programa principal
    // *******************************
    alert("Bienvenido a la Tienda Online con Reservas Red Sport SA");
    let seguir = true;

    while (seguir) {
      mostrarProductos();
      const opcion = prompt("Opciones: \n- Ingresa ID para agregar al carrito\n- 1 o 'ver' para ver carrito\n- 2 o 'reservar' para hacer una reserva\n- 3 o 'ver reservas' para ver reservas\n- 4 o 'fin' para finalizar");

      if (opcion === "fin" || opcion === "4") {
        seguir = false;
      } else if (opcion === "ver" || opcion === "1") {
        mostrarCarrito();
      } else if (opcion === "reservar" || opcion === "2") {
        const id = parseInt(prompt("Ingresa ID del producto a reservar:"));
        const nombre = prompt("Ingresa tu nombre:");
        const fecha = prompt("Ingresa fecha de reserva (ej: 23/07/2025):");
        hacerReserva(id, nombre, fecha);
      } else if (opcion === "ver reservas" || opcion === "3") {
        mostrarReservas();
      } else {
        const id = parseInt(opcion);
        if (!isNaN(id)) {
          agregarAlCarrito(id);
        } else {
          console.log("Entrada inválida.");
        }
      }
    }

    mostrarCarrito();
    mostrarReservas();
    alert("Gracias por visitar nuestra Tienda - Familia Red Sport");

